from .models import Costumes
from .models import Orders
from django.forms import ModelForm, TextInput, DateTimeInput, Textarea
class CostumesForm(ModelForm):
    class Meta:
        model = Costumes
        fields = ['CostumesName', 'CostumesDescription', 'CostumesCondition', 'CostumesDate']

        widgets = {
            "CostumesName": TextInput (attrs={
                'class':'form-control',
                'placeholder':'Название костюма'
            }),
            "CostumesDescription": TextInput(attrs={
                'class':'form-control',
                'placeholder':'Описание костюма'
            }),
            "CostumesCondition": DateTimeInput(attrs={
                'class':'form-control',
                'placeholder':'Состояние костюма'
            }),
            "CostumesDate": Textarea(attrs={
                'class':'date-control',
                'placeholder':'Дата заполнения'
            }),
        }
