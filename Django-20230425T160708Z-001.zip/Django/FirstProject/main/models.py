from django.db import models

class Costumes(models.Model):
    CostumesName = models.CharField('Название', max_length=50)
    CostumesDescription = models.CharField('Описание костюма', max_length=500, editable=True)
    CostumesCondition = models.CharField('Состояние костюма', max_length=50)
    CostumesLink = models.CharField('Ссылка', max_length=500)
    CostumesDate = models.DateTimeField('Дата последней проверки')

    def __str__(self):
        return self.CostumesName
    
    class Meta:
        verbose_name = 'Костюм'
        verbose_name_plural = 'Костюмы'
    
    def get_absolute_url(self):
        return f'/icontrol/{self.id}'