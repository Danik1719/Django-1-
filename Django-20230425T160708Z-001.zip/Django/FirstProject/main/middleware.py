# middleware.py

from django.shortcuts import redirect
from django.urls import reverse

class LoginRequiredMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        # Проверяем, авторизован ли пользователь
        if  request.user.is_authenticated:
            # Если пользователь не авторизован, перенаправляем его на страницу авторизации
            return redirect(reverse('login'))
        
        response = self.get_response(request)
        
        return response