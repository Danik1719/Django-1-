from django.contrib import admin
from .models import Costumes

admin.site.register(Costumes)