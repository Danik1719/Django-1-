from . import views
from django.urls import path
from django.shortcuts import render

urlpatterns = [
    path('', views.index , name='home'),
    path('icontrol/', views.icontrol, name='icontrol'),
    path('<int:pk>', views.CostumeDetailView.as_view(), name = 'icontrol-detail')
]