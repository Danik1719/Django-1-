from django.shortcuts import render
from django.http import HttpResponse
from .models import Costumes
from django.views.generic import DetailView, UpdateView, DeleteView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin

@login_required
def index(request):
    data = {
        'title':'Главная страница',
    }
    return render(request, 'main/site.html', data)

@login_required
def icontrol(request):
    costumes = Costumes.objects.all()
    data = {
        'title':'Складской учёт'
    }
    return render(request, 'main/icontrol.html', {'costumes':costumes})

class CostumeDetailView(DetailView):
    model = Costumes
    template_name = 'main/icontrol-detail.html'
    content_object_name = 'icontrol'
