from django.db import models

class Orders(models.Model):
    time_arrive = models.DateTimeField('К месту:')
    time_begin = models.DateTimeField('Начало:')
    character = models.CharField('Персонажи:', max_length=200)
    program = models.CharField('Программа:', max_length=200)
    description = models.CharField('Примечание', max_length=500)
    link = models.CharField('Ссылка:', max_length=500)
    price = models.BigIntegerField('Цена заказа: ')
    customer = models.CharField('Заказчик:', max_length=200, default = '')
    place = models.CharField('Место проведения:', max_length=200, default = '')

    class Meta:
        verbose_name = 'Заказ'
        verbose_name_plural = 'Заказы'
    
    def get_absolute_url(self):
        return f'/orders/{self.id}'
    
    
    def __str__(self):  
        return self.program
    