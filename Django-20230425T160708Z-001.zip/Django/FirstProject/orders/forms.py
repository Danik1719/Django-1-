from .models import Orders
from django.forms import ModelForm, TextInput, DateTimeInput, Textarea, forms
class OrdersForm (ModelForm):
    class Meta:
        model = Orders
        fields = ['time_arrive', 'place', 'customer', 'price', 'time_begin', 'character', 'program', 'description', 'link']

        widgets = {
            "time_arrive": TextInput (attrs={
                'class':'date-control',
                'placeholder':'К месту'
            }),
            "time_begin": TextInput(attrs={
                'class':'date-control',
                'placeholder':'Начало'
            }),
            "place": TextInput(attrs={
            'class':'form-control',
            'placeholder':'Место проведения'
            }),
            "customer": TextInput(attrs={
            'class':'form-control',
            'placeholder':'Данные клиента'
            }),
            "price": TextInput(attrs={
            'class':'fomr-control',
            'placeholder':'Цена'
            }),
            "character": TextInput(attrs={
                'class':'form-control',
                'placeholder':'Персонажи'
            }),
            "program": Textarea(attrs={
                'class':'form-control',
                'placeholder':'Программа'
            }),
            "description": Textarea(attrs={
                'class':'form-control',
                'placeholder':'Примечение'
            }),
            "link": Textarea(attrs={
                'class':'form-control',
                'placeholder':'ССЫЛКА'
            }),
        }
