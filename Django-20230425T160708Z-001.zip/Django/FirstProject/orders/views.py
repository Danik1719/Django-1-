from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Orders
from .forms import OrdersForm
from django.views.generic import DetailView, UpdateView, DeleteView
from django.db.models import F, Sum
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin

@login_required
def index(request):
    data = {
        'title':'Главная страница',
    }
    return render(request, 'main/site.html', data)
@login_required
def orders(request):
    orders = Orders.objects.all()
    return render(request, 'orders/orders.html', {'orders': orders})

@login_required
def create(request):
    if request.method == 'POST':
        form = OrdersForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('orders')
    else:
        error = 'Форма была неверной'

    form = OrdersForm()
    error = ''
 
    data = {
        'form': form,
        'error': error
    }
    return render(request, 'orders/create.html', data)  
    
@login_required
def sum(request):
    total_price = Orders.objects.aggregate(total_price=Sum('price'))['total_price']
    data = {'total_price': total_price}
    return render(request, 'orders/order-sum.html', data)
@login_required
def idrqst(request):
    orders = Orders.objects.first()
    return render(request, 'orders/order-sum.html', {'orders': orders})

    
class OrderDetailView(DetailView):
    model = Orders
    template_name = 'orders/order-detail.html'
    context_object_name = 'orders'

class DeleteOrder(DeleteView):
    model = Orders
    template_name = 'orders/delete-order.html'
    context_object_name = 'orders'
    success_url = '/orders/'

class UpdateOrder(UpdateView):
    model = Orders
    template_name = 'orders/create.html' 
    form_class = OrdersForm
