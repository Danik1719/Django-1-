from django.contrib import admin
from .models import Orders


admin.site.register(Orders)