from . import views
from django.urls import path
from django.shortcuts import render

urlpatterns = [
    path('', views.orders , name='orders'),
    path('create', views.create, name = 'create'),
    path('<int:pk>', views.OrderDetailView.as_view(), name = 'order-detail'),
    path('<int:pk>/delete', views.DeleteOrder.as_view(), name = 'delete-order'),
    path('<int:pk>/update', views.UpdateOrder.as_view(), name = 'update-order'),
    path('order-sum', views.sum, name='order-sum'),
    path('', views.idrqst, name='order-sum')
]